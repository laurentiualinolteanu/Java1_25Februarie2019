public class Ex2 {
    public static void main (String[] args) {
        OddNumberThread t = new OddNumberThread();
        //pentru pornirea unui thread
        t.start();
        
        //apelarea lui run() nu porneste un thread
        //t.run();
        
        EvenNumberRunnable r = new EvenNumberRunnable();
        Thread t2 = new Thread(r);
        //pentru pornirea unui thread
        t2.start();
        
        //apelarea lui run() nu porneste un thread
        //t2.run();
        System.out.println("THE END");
    }
}