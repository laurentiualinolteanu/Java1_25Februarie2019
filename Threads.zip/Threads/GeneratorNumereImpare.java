public class GeneratorNumereImpare {
    
    //metoda ce afiseaza toate numerele impare de la 0 la 1000 (exclusiv)
    public void afiseazaNumereleImpare() {
        for (int i = 0; i < 1000; i++) {
            if(i % 2 != 0) {
                System.out.println(i);
            }
        }
    }
}