public class GeneratorNumerePare {
    
    //metoda ce afiseaza toate numerele pare de la 0 la 1000 (exclusiv)
    public void afiseazaNumerelePare() {
        for (int i = 0; i < 1000; i++) {
            if(i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}