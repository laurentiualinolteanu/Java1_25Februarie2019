public class Ex4{
    public static void main(String[] args) {
        //t1 o sa retina timpul curent la momentul pornirii
        long t1 = System.currentTimeMillis();

        //se creeaza thread-ul tdb1 folosind constructorul new Thread(Runnable r)
        //Runnable este o interfata functionala si poate fi scris cu lambda
        Thread tdb1 = new Thread(() -> collectDataFromDB1());
        
        //se porneste thread-ul tdb1
        tdb1.start();
        
        //se creeaza thread-ul tdb2 folosind constructorul new Thread(Runnable r)
        Thread tdb2 = new Thread(() -> collectDataFromDB2());
        
        //se porneste thread-ul tdb2
        tdb2.start();
        
        try {
            //tdb1 este atasat thread-ului current ceea ce face thread-ul current sa astepte terminarea executiei lui tdb1 inainte de a continua cu
            //urmatoarea apelare
            tdb1.join();
            //tdb2 este atasat thread-ului current ceea ce face thread-ul current sa astepte terminarea executiei lui tdb2 inainte de a continua cu
            //urmatoarea apelare
            tdb2.join();
            
            //cele doua metode join de mai sus fac ca thread-ul current sa astepte terminarea ambelor executii inainte e a continua
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        //t2 o sa retina timpul curent la momentul terminarii
        long t2 = System.currentTimeMillis();
        
        //afiseaza numarul de milisecunde care au trecut de la pornire pana la oprire
        System.out.println(t2 -t1);
    }
    
    //metoda care pune thread-ul tdb1 sa astept 2000 milisecunde
    public static void collectDataFromDB1() {
        try {
            Thread.sleep(2000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    //metoda care pune thread-ul tdb2 sa astept 3000 milisecunde
    public static void collectDataFromDB2() {
        try {
            Thread.sleep(3000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
}