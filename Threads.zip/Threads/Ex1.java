public class Ex1 {
    public static void main (String[] args) {
        GeneratorNumerePare genPar = new GeneratorNumerePare();
        GeneratorNumereImpare genImpar = new GeneratorNumereImpare();
        
        genPar.afiseazaNumerelePare();
        genImpar.afiseazaNumereleImpare();
    }
}