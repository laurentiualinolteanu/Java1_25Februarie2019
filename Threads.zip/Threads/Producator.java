import java.util.*;

public class Producator extends Thread{
   private Random r = new Random(); 
    
   public Producator(String nume) {
       super(nume);
   }
   
   @Override
   public void run() {
       while(true) {
           synchronized(Ex5.list) {
               if (Ex5.list.size() < 100) {
                   int x = r.nextInt();
                   Ex5.list.add(x);
                   //notifia toate thread-urile ca a avut loc o modificare in lista noastra
                   Ex5.list.notifyAll();
                   System.out.println("A fost adaugat elementul " + x);
               } else {
                    try {
                       // facem thread-ul current sa se opreasca pana cand se mai goleste lista si putem sa adaugam alte elemente
                       Ex5.list.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
               }
            }
       }
   }
}