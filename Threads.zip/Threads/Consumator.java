public class Consumator extends Thread {
    public Consumator(String nume) {
        super(nume);
    }
    
    @Override
    public void run() {
        while(true) {
            
            synchronized(Ex5.list) {
                if (!Ex5.list.isEmpty()) {
                    int x = Ex5.list.get(0);
                    Ex5.list.remove(0);
                   //notifia toate thread-urile ca a avut loc o modificare in lista noastra
                    Ex5.list.notifyAll();
                    System.out.println("A fost eliminat elementul " + x);
                } else {
                    try {
                       //facem thread-ul current sa se opreasca pana cand apar elemente in lista
                       Ex5.list.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}