public class Ex3{
    public static void main(String[] args) {
        
        //t1 o sa retina timpul curent la momentul pornirii
        long t1 = System.currentTimeMillis();
        //apeleaza metoda collectDataFromDB1() care pune thread-ul principal sa astepte 2000 milisecund
        collectDataFromDB1();
        //apeleaza metoda collectDataFromDB2() care pune thread-ul principal sa astepte 3000 milisecund
        collectDataFromDB2();
        //t2 o sa retina timpul curent la momentul terminarii
        long t2 = System.currentTimeMillis();
        //afiseaza numarul de milisecunde care au trecut de la pornire pana la oprire
        System.out.println(t2 -t1);
    }
    
    //metoda care pune thread-ul curent sa astept 2000 milisecunde
    public static void collectDataFromDB1() {
        try {
            Thread.sleep(2000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    //metoda care pune thread-ul curent sa astept 3000 milisecunde
    public static void collectDataFromDB2() {
        try {
            Thread.sleep(3000);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
}